# CCCP Chatbot Widget - Professional Implementation

## 🎯 Overview
A professional, embeddable chatbot widget designed specifically for CCCP with custom burgundy color palette and typography system.

## 🎨 Design Features
- **Native CCCP Feel**: Matches your website's design perfectly
- **Professional Typography**: Montserrat headers + Open Sans body text
- **Custom Color Palette**: Deep burgundy (#591C27) with accent colors
- **Responsive Design**: Works on all devices
- **Smooth Animations**: Professional hover effects and transitions

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment
```bash
cp .env.example .env
# Edit .env and add your OPENAI_API_KEY
```

### 3. Start the Server
```bash
npm start
# Server runs on http://localhost:3000
```

### 4. Test the Widget
- Open http://localhost:3000
- Click the floating "CHAT" button
- See your custom CCCP styling in action

## 📁 File Structure
```
cccp-chatbot-export/
├── api/
│   └── server.js          # Express server with OpenAI integration
├── widget/
│   └── widget.js          # Embeddable widget with CCCP styling
├── cccp-widget.css        # Clean CSS file for reference
├── theme.ts               # Tailwind configuration
├── package.json           # Dependencies
├── .env.example           # Environment template
└── index.html             # Test page
```

## 🎨 Color Palette
```css
--cccp-primary: #591C27      /* Deep burgundy (header/nav) */
--cccp-primaryDark: #401017  /* Darker shade for hover */
--cccp-accent: #8B2E3A       /* Link + button accent */
--cccp-text: #1F1F1F         /* Primary text color */
--cccp-border: #E4E4E4       /* Input/card borders */
--cccp-background: #FFFFFF   /* Global background */
--cccp-botBubble: #F9F9F9    /* Bot message background */
--cccp-userBubble: #8B2E3A   /* User message background */
```

## 🔤 Typography System
- **Headers & Buttons**: Montserrat (600-700 weight)
- **Body Text**: Open Sans (400 weight)
- **Placeholders**: Open Sans (300 weight)

## 🌐 Embedding on Your Website

### Option 1: Direct Script Tag
```html
<script defer src="https://your-domain.com/widget/widget.js"></script>
```

### Option 2: Self-Hosted
1. Upload the `widget/` folder to your server
2. Add the script tag pointing to your server
3. Ensure CORS is configured properly

## ⚙️ Configuration

### Environment Variables
```bash
OPENAI_API_KEY=your_openai_key_here
PORT=3000
ALLOWED_ORIGINS=https://yourdomain.com,https://www.yourdomain.com
KNOWLEDGE_WITH_EMBEDDINGS=0
```

### Customization
- Edit `widget/widget.js` for styling changes
- Modify `api/server.js` for backend logic
- Use `cccp-widget.css` as reference for custom implementations

## 🚀 Deployment Options

### Vercel (Recommended)
1. Import this repository to Vercel
2. Set environment variables in Vercel dashboard
3. Deploy automatically

### Other Platforms
- **Netlify**: Works with serverless functions
- **Railway**: Easy Node.js deployment
- **DigitalOcean**: App Platform deployment

## 📱 Features
- ✅ Professional CCCP branding
- ✅ OpenAI GPT-4o-mini integration
- ✅ Lead capture forms
- ✅ Rate limiting protection
- ✅ Responsive design
- ✅ Custom scrollbars
- ✅ Smooth animations
- ✅ Mobile optimized

## 🎯 Production Checklist
- [ ] Set up OpenAI API key
- [ ] Configure CORS for your domain
- [ ] Test on mobile devices
- [ ] Verify lead capture functionality
- [ ] Set up monitoring/analytics
- [ ] Configure SSL certificate

## 📞 Support
This widget is designed to feel native to your CCCP website and provide a professional, trustworthy user experience.

---
**Ready for Production** ✅
