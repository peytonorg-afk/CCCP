(function(){
  // Inject Google Fonts
  const fontLink = document.createElement('link');
  fontLink.href = 'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Open+Sans:wght@300;400;600&display=swap';
  fontLink.rel = 'stylesheet';
  document.head.appendChild(fontLink);

  const style = document.createElement('style');
  style.textContent = `
    :root {
      --cccp-primary: #591C27;
      --cccp-primaryDark: #401017;
      --cccp-accent: #8B2E3A;
      --cccp-text: #1F1F1F;
      --cccp-border: #E4E4E4;
      --cccp-background: #FFFFFF;
      --cccp-botBubble: #F9F9F9;
      --cccp-userBubble: #8B2E3A;
      --cccp-shadow: rgba(0,0,0,0.15);
    }
    
    #bb-chat-btn{
      position:fixed;right:20px;bottom:20px;padding:14px 20px;border-radius:9999px;
      background: linear-gradient(135deg, var(--cccp-accent), var(--cccp-primary));
      color:#fff;border:1px solid rgba(255,255,255,.12);cursor:pointer;
      box-shadow:0 8px 24px var(--cccp-shadow);font-weight:600;
      transition:all 0.3s ease;font-family:"Montserrat","Helvetica Neue",sans-serif;
      font-size:14px;letter-spacing:0.5px;text-transform:uppercase;
    }
    #bb-chat-btn:hover{
      filter:brightness(1.06);transform:translateY(-2px);
      box-shadow:0 12px 32px var(--cccp-shadow);
    }
    
    #bb-box{
      display:none;position:fixed;right:20px;bottom:80px;width:380px;max-width:95vw;height:540px;
      background:var(--cccp-background);border-radius:16px;
      box-shadow:0 20px 48px var(--cccp-shadow);
      overflow:hidden;border:1px solid var(--cccp-border);
      font-family:"Open Sans","Roboto",sans-serif;
    }
    
    #bb-head{
      padding:16px 20px;font-weight:600;border-bottom:1px solid var(--cccp-border);
      background:var(--cccp-primary);color:#fff;
      font-family:"Montserrat","Helvetica Neue",sans-serif;font-size:16px;
      letter-spacing:0.3px;
    }
    
    #bb-msgs{
      height:400px;overflow:auto;padding:16px;background:var(--cccp-background);
      scrollbar-width:thin;scrollbar-color:var(--cccp-border) transparent;
    }
    #bb-msgs::-webkit-scrollbar{width:6px}
    #bb-msgs::-webkit-scrollbar-track{background:transparent}
    #bb-msgs::-webkit-scrollbar-thumb{background:var(--cccp-border);border-radius:3px}
    
    .msg{
      margin:12px 0;font:14px/1.5 "Open Sans","Roboto",sans-serif;
      padding:12px 16px;border-radius:16px;max-width:85%;
      box-shadow:0 2px 8px var(--cccp-shadow);
    }
    .you{
      text-align:right;background:var(--cccp-userBubble);color:#fff;
      margin-left:20px;border-bottom-right-radius:4px;
    }
    .bot{
      text-align:left;background:var(--cccp-botBubble);color:var(--cccp-text);
      border:1px solid var(--cccp-border);margin-right:20px;
      border-bottom-left-radius:4px;
    }
    
    #bb-form{
      display:flex;gap:12px;padding:16px;border-top:1px solid var(--cccp-border);
      background:var(--cccp-background);
    }
    #bb-input{
      flex:1;padding:12px 16px;border:1px solid var(--cccp-border);
      border-radius:12px;background:var(--cccp-background);color:var(--cccp-text);
      font-family:"Open Sans","Roboto",sans-serif;font-size:14px;
      transition:border-color 0.3s ease;
    }
    #bb-input:focus{
      outline:none;border-color:var(--cccp-accent);
      box-shadow:0 0 0 3px rgba(139,46,58,0.1);
    }
    #bb-input::placeholder{
      color:var(--cccp-text);opacity:0.6;font-weight:300;
    }
    #bb-send{
      padding:12px 18px;border-radius:12px;border:0;
      background:var(--cccp-accent);color:#fff;cursor:pointer;
      font-weight:600;font-family:"Montserrat","Helvetica Neue",sans-serif;
      font-size:14px;transition:all 0.3s ease;
    }
    #bb-send:hover{
      background:var(--cccp-primary);transform:translateY(-1px);
    }
    
    #bb-lead{
      padding:16px;border-top:1px solid var(--cccp-border);
      background:var(--cccp-background);
    }
    #bb-lead input{
      width:100%;padding:12px 16px;border:1px solid var(--cccp-border);
      border-radius:12px;margin:8px 0;background:var(--cccp-background);
      color:var(--cccp-text);font-family:"Open Sans","Roboto",sans-serif;
      font-size:14px;transition:border-color 0.3s ease;
    }
    #bb-lead input:focus{
      outline:none;border-color:var(--cccp-accent);
      box-shadow:0 0 0 3px rgba(139,46,58,0.1);
    }
    #bb-lead input::placeholder{
      color:var(--cccp-text);opacity:0.6;font-weight:300;
    }
    #bb-lead button{
      padding:12px 18px;border:0;border-radius:12px;
      background:var(--cccp-accent);color:#fff;cursor:pointer;
      font-weight:600;font-family:"Montserrat","Helvetica Neue",sans-serif;
      font-size:14px;transition:all 0.3s ease;margin-top:8px;
    }
    #bb-lead button:hover{
      background:var(--cccp-primary);transform:translateY(-1px);
    }
    
    /* Professional spacing and typography */
    .msg p{margin:0;padding:0}
    .msg strong{font-weight:600}
    .msg em{font-style:italic;opacity:0.8}
  `;
  document.head.appendChild(style);

  const btn = document.createElement('button'); btn.id='bb-chat-btn'; btn.textContent='Chat';
  const box = document.createElement('div'); box.id='bb-box';
  box.innerHTML = `
    <div id="bb-head" aria-live="polite">How can we help?</div>
    <div id="bb-msgs" role="log" aria-live="polite"></div>
    <form id="bb-form" aria-label="Chat input">
      <input id="bb-input" placeholder="Type your question…" autocomplete="off" aria-label="Message"/>
      <button id="bb-send" type="submit" aria-label="Send message">Send</button>
    </form>
    <div id="bb-lead" style="display:none">
      <div style="font:600 14px system-ui;margin-bottom:6px">Leave your details and we’ll follow up:</div>
      <input id="bb-name" placeholder="Name"/>
      <input id="bb-email" placeholder="Email"/>
      <button id="bb-lead-send">Send</button>
    </div>
  `;
  document.body.append(btn, box);

  const msgs = document.getElementById('bb-msgs');
  const form = document.getElementById('bb-form');
  const input = document.getElementById('bb-input');
  const lead = document.getElementById('bb-lead');
  const leadBtn = document.getElementById('bb-lead-send');
  const nameIn = document.getElementById('bb-name');
  const emailIn = document.getElementById('bb-email');

  const sessionId = crypto.randomUUID();

  btn.onclick = ()=> box.style.display = (box.style.display==='none'||!box.style.display)?'block':'none';
  document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') box.style.display='none'; });

  function add(role, text){
    const d=document.createElement('div'); d.className=`msg ${role}`; d.textContent=text;
    msgs.appendChild(d); msgs.scrollTop = msgs.scrollHeight;
  }

  async function ask(q){
    add('you', q);
    const r = await fetch('/api/chat', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ sessionId, message:q })
    });
    const data = await r.json();
    add('bot', data.reply || 'Sorry, I had trouble answering that.');
    if (data.handoffSuggested) lead.style.display='block';
  }

  form.addEventListener('submit', async (e)=>{ e.preventDefault();
    const q = input.value.trim(); if(!q) return; input.value=''; await ask(q);
  });

  leadBtn.addEventListener('click', async ()=>{
    const name = nameIn.value.trim(), email = emailIn.value.trim();
    if(!name || !email) return alert('Please add name and email');
    const message = 'Lead from chat widget';
    await fetch('/api/lead',{ method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ name,email,message })});
    lead.style.display='none'; add('bot','Thanks! We’ll follow up shortly.');
  });
})();
