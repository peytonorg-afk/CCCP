import "dotenv/config";
import express from "express";
import bodyParser from "body-parser";
import OpenAI from "openai";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { v4 as uuidv4 } from "uuid";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const ALLOWED = (process.env.ALLOWED_ORIGINS || "").split(",").map(s=>s.trim()).filter(Boolean);
const USE_VECTORS = process.env.KNOWLEDGE_WITH_EMBEDDINGS === "1";

app.use(bodyParser.json());
app.use((req,res,next)=>{
  const origin = req.headers.origin || "";
  // Allow requests without Origin (same-origin or server-to-server)
  if (!origin) return next();
  if (!ALLOWED.length || ALLOWED.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    res.setHeader("Access-Control-Allow-Methods", "POST,GET,OPTIONS");
    if (req.method === "OPTIONS") return res.sendStatus(200);
    return next();
  }
  return res.status(403).json({ error: "Origin not allowed" });
});
app.use("/widget", express.static(path.join(__dirname, "..", "widget")));

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// --- Load knowledge base (if present)
const KB_PATH = path.resolve(__dirname, "..", "docs", "knowledge.jsonl");
let KB_ROWS = [];
try {
  if (fs.existsSync(KB_PATH)) {
    KB_ROWS = fs.readFileSync(KB_PATH, "utf8").split("\n").filter(Boolean).map(JSON.parse);
    console.log(`[KB] Loaded ${KB_ROWS.length} chunks from docs/knowledge.jsonl`);
  } else {
    console.warn("[KB] No knowledge.jsonl found. Continuing without KB.");
  }
} catch (e) {
  console.error("[KB] Failed to load knowledge:", e.message);
}

// --- Retrieval helpers
function scoreKeyword(q, text){
  const qTerms = q.toLowerCase().split(/\W+/).filter(Boolean);
  const t = text.toLowerCase();
  let score = 0;
  for (const term of qTerms) score += Math.min((t.split(term).length - 1), 5);
  return score;
}
function retrieveKeyword(q, k=6){
  if (!KB_ROWS.length) return [];
  const arr = KB_ROWS.map(r => ({
    r, s: scoreKeyword(q, (r.title || "") + " " + r.content.slice(0,1500))
  }));
  arr.sort((a,b)=>b.s-a.s);
  return arr.filter(x=>x.s>0).slice(0,k).map(x=>x.r);
}
function cosine(a,b){
  let dot=0,na=0,nb=0;
  for (let i=0;i<a.length;i++){ dot+=a[i]*b[i]; na+=a[i]*a[i]; nb+=b[i]*b[i]; }
  return dot / (Math.sqrt(na)*Math.sqrt(nb)+1e-9);
}
async function retrieveVector(q, k=6){
  if (!KB_ROWS.length) return [];
  const vecRows = KB_ROWS.filter(r=>Array.isArray(r.embedding));
  if (!vecRows.length) return [];
  const e = await openai.embeddings.create({ model: "text-embedding-3-small", input: q });
  const qv = e.data[0].embedding;
  const scored = vecRows.map(r=>({ r, s: cosine(qv, r.embedding) }));
  scored.sort((a,b)=>b.s-a.s);
  return scored.slice(0,k).map(x=>x.r);
}
function dedupById(list){
  const seen = new Set();
  const out = [];
  for (const r of list) { if (!seen.has(r.id)) { seen.add(r.id); out.push(r);} }
  return out;
}
function estimateConfidence(passages){
  if (!passages.length) return 0.3;
  const L = Math.min((passages[0].content?.length || 0)/800, 1);
  return Math.max(0.35, Math.min(0.9, 0.5 + 0.4*L));
}

// --- Rate limit (very simple)
const buckets = new Map();
function rateLimit(key, limit=20, windowMs=5*60*1000){
  const now=Date.now();
  const b = buckets.get(key) || { tokens: limit, reset: now+windowMs };
  if (now > b.reset) { b.tokens = limit; b.reset = now+windowMs; }
  if (b.tokens <= 0) return false;
  b.tokens -= 1; buckets.set(key,b); return true;
}

// --- Routes
app.post("/api/chat", async (req,res)=>{
  try {
    const ip = req.headers["x-forwarded-for"]?.toString().split(",")[0] || req.socket.remoteAddress || "ip";
    if (!rateLimit(ip)) return res.status(429).json({ reply: "Too many requests, please wait a moment." });

    const { message, sessionId } = req.body || {};
    const sid = sessionId || uuidv4();
    if (!message || typeof message !== "string" || message.length > 4000) {
      return res.status(400).json({ reply: "Please send a shorter message." });
    }

    const kw = retrieveKeyword(message, 6);
    const vec = USE_VECTORS ? await retrieveVector(message, 6) : [];
    const passages = dedupById([...(vec||[]), ...kw]).slice(0,6);
    const confidence = estimateConfidence(passages);

    if (confidence < 0.4) {
      return res.json({
        reply: "I might not have the exact info yet. Could I get your name and email so a teammate can follow up?",
        confidence,
        handoffSuggested: true
      });
    }

    const context = passages.map((p,i)=>`[${i+1}] ${p.title} — ${p.url}\n• ${p.content.slice(0,600)}`).join("\n\n");
    const system = "Only answer from the Context. If missing, say you don’t know and ask for name/email. ≤80 words. Add citations like [1], [2].";
    const chat = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      temperature: 0.2,
      messages: [
        { role: "system", content: system },
        { role: "user", content: `Context:\n${context}\n\nUser: ${message}` }
      ]
    });
    const reply = chat.choices[0]?.message?.content?.trim() || "Sorry, I’m not sure yet.";

    res.json({
      reply,
      confidence,
      handoffSuggested: false,
      sources: passages.map((p,i)=>({ i:i+1, title:p.title, url:p.url })),
      sessionId: sid
    });
  } catch (e) {
    console.error("CHAT ERROR", e);
    res.status(500).json({ reply: "Oops—something went wrong. Can I get your name and email so we can follow up?" });
  }
});

app.post("/api/lead", async (req,res)=>{
  const { name, email, message } = req.body || {};
  if (!name || !email) return res.status(400).json({ ok:false, error:"Missing name or email" });
  console.log(`[LEAD] ${new Date().toISOString()} name="${name}" email="${email}" msg="${(message||"").slice(0,200)}"`);
  // TODO: replace with SMTP or CRM webhook
  res.json({ ok:true });
});

app.get("/", (req,res)=>{
  res.sendFile(path.join(__dirname, "..", "index.html"));
});

app.listen(PORT, ()=> console.log(`Chat API running on http://localhost:${PORT}`));
